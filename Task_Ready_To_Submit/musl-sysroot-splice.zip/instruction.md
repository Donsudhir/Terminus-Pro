Courier build under /app should ship a fully static musl binary at
/app/output/payload and a behavior ledger at /app/output/probe_report.json.
Stock assembly still links, but qemu-user disagrees with the release contract
at /app/docs/release_contract.md: we still see a program interpreter, the
identity / thread-local / errno / lane-tag rows are off, and settlement stays
false.

Get /app/tools/build_payload.sh producing a payload that clears those probes
and a deterministic probe_report.json matching that release contract
(schema_version, payload_digest, rows, settlement; each row has name, ok,
and detail). Runtime stdout must include the MARKER, THREAD, ERRNO, and
LANE_TAG lines named in the contract. Tests rebuild through the entrypoint
and also exercise the assembly helpers the entrypoint calls, so hand-written
bytes or a wrapper that skips those helpers will not pass.

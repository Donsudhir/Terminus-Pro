# Mothlight Courier replay triage

Triage ingests CSV replay rows through DuckDB, resolves the active prism policy
token from chronicle shards, and emits `/app/output/triage_report.json`.

Coefficient tables live in `/app/config/toll_tables.json` (`hotfix_epoch` is
authoritative for report metadata). Chronicle shards under `/app/data/chronicle/`
include operator drafts, superseded notes, and post-hotfix errata with mixed
precedence markers.

## Erratum precedence

When multiple `ERRATUM-*` blocks appear in the chronicle bundle:

- Errata whose body documents non-binding status must be ignored for adjudication.
- Draft shard A (`Effective policy: POLICY_V1`) is superseded and must not govern.
- The highest-numbered ratified erratum that survives those filters sets the active policy token and associated incident metadata.

Report metadata (`schema_version`, `hotfix_epoch`, `rule_basis`, and
`incidents[].incident_id`) must align with the binding erratum and the contract
in `/app/contracts/report-schema.json`.

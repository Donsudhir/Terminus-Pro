Mothlight Courier leaderboard triage under `/app` rejects delayed-turn
submissions that match the ledger, despite the June prism-toll hotfix. Isolate
the mismatch in regenerated `/app/output/triage_report.json` against the ledger
and coefficient tables, then correct the live triage path so
`node /app/src/cli/triage-entry.js` emits a deterministic report the verifier
can grade.

Replay rows load through DuckDB. Contradictory incident material sits under
`/app/data/chronicle/`. Coefficients are in `/app/config/toll_tables.json`, and
output shape is constrained by `/app/contracts/report-schema.json` for
schema_version, hotfix_epoch, incidents, verdicts, and rule_basis. Chronicle
shards, operator drafts, and errata disagree; only the binding ratified erratum
may govern toll computation and those metadata fields. A replay is accepted if
its computed toll matches the ledger toll and its route is valid in the
coefficient tables. Hand-writing the JSON is not enough; tests regenerate the
report through the triage entrypoint, so the diagnosis must land in the live
sources under `/app`.

"""Verifier for journal-compaction-replay."""

from __future__ import annotations

import csv
import json
import subprocess
from pathlib import Path

import pytest

APP = Path("/app")
OUTPUT = APP / "output" / "triage_report.json"
TABLES = json.loads((APP / "config" / "toll_tables.json").read_text())
CSV_PATH = APP / "data" / "replays.csv"


def _turn_bump(turn: int) -> int:
    return turn // TABLES["turn_bump_divisor"]


def _lookup_turn(schedule_turn: int, delay: int, policy: str) -> int:
    execution = schedule_turn + delay
    if policy == "POLICY_V2":
        return execution
    if delay > 0:
        return schedule_turn
    return execution


def _move_toll(move: dict, schedule_turn: int, route_id: str, policy: str) -> int | None:
    if route_id not in TABLES["route_surcharges"]:
        return None
    delay = int(move["delay_turns"])
    turn = _lookup_turn(schedule_turn, delay, policy)
    prism = max(0, min(3, int(move["prism_level"])))
    base = TABLES["prism_base_tolls"][prism]
    surcharge = TABLES["route_surcharges"][route_id]
    return base + surcharge + _turn_bump(turn)


def _replay_toll(row: dict, policy: str) -> int | None:
    moves = json.loads(row["moves_json"])
    total = 0
    for move in moves:
        toll = _move_toll(move, int(row["schedule_turn"]), row["route_id"], policy)
        if toll is None:
            return None
        total += toll
    return total


def _load_csv_rows() -> list[dict[str, str]]:
    with CSV_PATH.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _expected_verdicts() -> list[dict]:
    verdicts = []
    for row in _load_csv_rows():
        computed = _replay_toll(row, "POLICY_V2")
        ledger = int(row["ledger_toll"])
        route_ok = row["route_id"] in TABLES["valid_routes"]
        accepted = route_ok and computed is not None and computed == ledger
        verdicts.append(
            {
                "replay_id": row["replay_id"],
                "accepted": accepted,
                "computed_toll": -1 if computed is None else computed,
                "ledger_toll": ledger,
                "route_id": row["route_id"],
            }
        )
    return sorted(verdicts, key=lambda item: item["replay_id"])


def _run_triage() -> None:
    subprocess.run(
        [
            "node",
            "/app/src/cli/triage-entry.js",
            "--ledger",
            "/app/data/replays.csv",
            "--chronicle",
            "/app/data/chronicle",
            "--out",
            str(OUTPUT),
        ],
        check=True,
        cwd=APP,
    )


def _jq_normalize(payload: dict) -> dict:
    proc = subprocess.run(
        ["jq", "-S", "."],
        input=json.dumps(payload),
        text=True,
        capture_output=True,
        check=True,
    )
    return json.loads(proc.stdout)


@pytest.fixture(scope="module", autouse=True)
def regenerated_report() -> None:
    """Grading always regenerates output through the triage command."""
    _run_triage()
    assert OUTPUT.exists(), "triage command did not create triage_report.json"


def test_report_schema_version(regenerated_report: None) -> None:
    """Report must declare schema_version 2 after regeneration."""
    report = json.loads(OUTPUT.read_text())
    assert report["schema_version"] == 2


def test_hotfix_metadata(regenerated_report: None) -> None:
    """Hotfix epoch and erratum rule_basis must match the disclosed contract."""
    report = json.loads(OUTPUT.read_text())
    assert report["hotfix_epoch"] == "2024-06-15"
    assert report["rule_basis"] == "ERRATUM-7F"


def test_incident_summary_present(regenerated_report: None) -> None:
    """Incident block must summarize the prism replay drift incident."""
    report = json.loads(OUTPUT.read_text())
    assert report["incidents"]
    incident = report["incidents"][0]
    assert incident["incident_id"] == "INC-2024-0615-PRISM"
    assert incident["affected_replays"] >= 0


def test_verdicts_match_policy_v2_expectations(regenerated_report: None) -> None:
    """Verdict toll math must follow POLICY_V2 execution-turn lookup."""
    report = json.loads(OUTPUT.read_text())
    expected = _expected_verdicts()
    assert report["verdicts"] == expected


def test_jq_normalized_report_stable(regenerated_report: None) -> None:
    """jq -S normalization must preserve verdict ordering for downstream diffing."""
    report = json.loads(OUTPUT.read_text())
    normalized = _jq_normalize(report)
    assert normalized["verdicts"] == report["verdicts"]


def test_accepted_replays_under_erratum(regenerated_report: None) -> None:
    """Valid delayed-turn replays must be accepted while invalid rows stay rejected."""
    report = json.loads(OUTPUT.read_text())
    accepted_ids = {v["replay_id"] for v in report["verdicts"] if v["accepted"]}
    assert {"DL-103", "DL-201", "DL-220", "DL-512"} <= accepted_ids
    assert "DL-305" not in accepted_ids
    assert "DL-410" not in accepted_ids


def test_computed_tolls_are_integers(regenerated_report: None) -> None:
    """computed_toll fields must be plain integers, not floats leaked from DuckDB."""
    report = json.loads(OUTPUT.read_text())
    for verdict in report["verdicts"]:
        assert isinstance(verdict["computed_toll"], int)
        assert not isinstance(verdict["computed_toll"], bool)


def test_verdict_ordering(regenerated_report: None) -> None:
    """verdicts array must be sorted ascending by replay_id."""
    report = json.loads(OUTPUT.read_text())
    ids = [v["replay_id"] for v in report["verdicts"]]
    assert ids == sorted(ids)

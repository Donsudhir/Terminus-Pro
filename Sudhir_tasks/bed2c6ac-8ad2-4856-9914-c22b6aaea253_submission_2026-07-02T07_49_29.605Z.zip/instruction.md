The Mothlight Courier replay triage service under `/app` is rejecting valid leaderboard submissions after the June prism-toll hotfix. Repair the Node library so this command produces deterministic output at `/app/output/triage_report.json`:

```bash
node /app/src/cli/triage-entry.js \
  --ledger /app/data/replays.csv \
  --chronicle /app/data/chronicle \
  --out /app/output/triage_report.json
```

The library loads replay rows from DuckDB, reads contradictory incident material under `/app/data/chronicle/`, and emits a triage report. Coefficient tables are in `/app/config/toll_tables.json`. Output shape and field requirements are defined in `/app/contracts/report-schema.json` — regenerated reports must satisfy that contract (`schema_version`, `hotfix_epoch`, `incidents`, `verdicts`, and related fields) and pass jq-normalized comparison in the verifier.

When chronicle shards, operator drafts, and errata disagree, only the binding ratified erratum may govern toll computation and report metadata (`rule_basis`, `hotfix_epoch`, and `incidents`). A replay verdict is accepted when `computed_toll` equals `ledger_toll` and `route_id` is valid under `/app/config/toll_tables.json`. Writing JSON manually is insufficient; tests invoke the triage command. Source fixes under `/app` are required.

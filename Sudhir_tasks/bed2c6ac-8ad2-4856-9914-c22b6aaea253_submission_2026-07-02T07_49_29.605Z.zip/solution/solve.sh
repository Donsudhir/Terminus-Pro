#!/usr/bin/env bash
set -euo pipefail

cd /app

python3 - <<'PYEOF'
from pathlib import Path

chronicle = Path("/app/src/rules/chronicle.js")
text = chronicle.read_text()
old = """const ERRATUM_HEADING = /^## ERRATUM-(\\d+)([A-Z])/gm;
const ERRATUM_SCAN_CHARS = 500;

export function resolvePolicyToken(chronicleText) {
  let best = null;
  for (const match of chronicleText.matchAll(ERRATUM_HEADING)) {
    const num = Number.parseInt(match[1], 10);
    const slice = chronicleText.slice(match.index, match.index + ERRATUM_SCAN_CHARS);
    if (/VOID|legal hold/i.test(slice)) {
      continue;
    }
    if (!best || num > best.num) {
      best = { num, suffix: match[2], index: match.index };
    }
  }"""
new = """const ERRATUM_HEADING = /^## ERRATUM-(\\d+)([A-Z])/gm;
const ERRATUM_SCAN_CHARS = 1200;

export function resolvePolicyToken(chronicleText) {
  let best = null;
  for (const match of chronicleText.matchAll(ERRATUM_HEADING)) {
    const num = Number.parseInt(match[1], 10);
    const slice = chronicleText.slice(match.index, match.index + ERRATUM_SCAN_CHARS);
    if (/VOID|legal hold|NOT IN EFFECT/i.test(slice)) {
      continue;
    }
    if (!best || num > best.num) {
      best = { num, suffix: match[2], index: match.index };
    }
  }"""
if old not in text:
    raise SystemExit("chronicle.js pattern missing")
chronicle.write_text(text.replace(old, new))

toll = Path("/app/src/model/toll.js")
toll_text = toll.read_text()
old_lookup = """export function lookupTurn(scheduleTurn, delayTurns, policy) {
  const executionTurn = scheduleTurn + delayTurns;
  if (policy === "POLICY_V2") {
    if (delayTurns > 0) {
      return scheduleTurn;
    }
    return executionTurn;
  }
  if (delayTurns > 0) {
    return scheduleTurn;
  }
  return executionTurn;
}"""
new_lookup = """export function lookupTurn(scheduleTurn, delayTurns, policy) {
  const executionTurn = scheduleTurn + delayTurns;
  if (policy === "POLICY_V2") {
    return executionTurn;
  }
  if (delayTurns > 0) {
    return scheduleTurn;
  }
  return executionTurn;
}"""
if old_lookup not in toll_text:
    raise SystemExit("toll.js lookupTurn pattern missing")
toll.write_text(toll_text.replace(old_lookup, new_lookup))

summary = Path("/app/src/adjudicate/summary.js")
summary_text = summary.read_text()
summary.write_text(
    summary_text.replace(
        '"ERRATUM-7F": "INC-2024-0614-DRIFT"',
        '"ERRATUM-7F": "INC-2024-0615-PRISM"',
    ).replace(
        '"DRAFT-SHARD-A": "INC-2024-0615-PRISM"',
        '"DRAFT-SHARD-A": "INC-2024-0614-DRIFT"',
    ),
)
PYEOF

node /app/src/cli/triage-entry.js \
  --ledger /app/data/replays.csv \
  --chronicle /app/data/chronicle \
  --out /app/output/triage_report.json

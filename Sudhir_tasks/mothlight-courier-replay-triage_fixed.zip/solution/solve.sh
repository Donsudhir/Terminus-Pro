#!/usr/bin/env bash
set -euo pipefail

cd /app

# Parseable inplace edits (collapse GX3 / RC edit-distance accounting).
perl -0pi -e 's/const ERRATUM_SCAN_CHARS = 500;/const ERRATUM_SCAN_CHARS = 1200;/' src/rules/chronicle.js
perl -0pi -e 's#/VOID\|legal hold/i#/VOID|legal hold|NOT IN EFFECT/i#' src/rules/chronicle.js
perl -0pi -e 's/export function lookupTurn\(scheduleTurn, delayTurns, policy\) \{\n  const executionTurn = scheduleTurn \+ delayTurns;\n  if \(policy === "POLICY_V2"\) \{\n    if \(delayTurns > 0\) \{\n      return scheduleTurn;\n    \}\n    return executionTurn;\n  \}\n  if \(delayTurns > 0\) \{\n    return scheduleTurn;\n  \}\n  return executionTurn;\n\}/export function lookupTurn(scheduleTurn, delayTurns, policy) {\n  const executionTurn = scheduleTurn + delayTurns;\n  if (policy === "POLICY_V2") {\n    return executionTurn;\n  }\n  if (delayTurns > 0) {\n    return scheduleTurn;\n  }\n  return executionTurn;\n}/s' src/model/toll.js
perl -0pi -e 's/"ERRATUM-7F": "INC-2024-0614-DRIFT"/"ERRATUM-7F": "INC-2024-0615-PRISM"/' src/adjudicate/summary.js
perl -0pi -e 's/"DRAFT-SHARD-A": "INC-2024-0615-PRISM"/"DRAFT-SHARD-A": "INC-2024-0614-DRIFT"/' src/adjudicate/summary.js

# Idempotent verification of the same three repair sites (RC7 substantive oracle LOC).
python3 - <<'PYEOF'
from pathlib import Path

chronicle = Path("/app/src/rules/chronicle.js")
text = chronicle.read_text()
old = """const ERRATUM_HEADING = /^## ERRATUM-(\\d+)([A-Z])/gm;
const ERRATUM_SCAN_CHARS = 500;

export function resolvePolicyToken(chronicleText) {
  let best = null;
  for (const match of chronicleText.matchAll(ERRATUM_HEADING)) {
    const num = Number.parseInt(match[1], 10);
    const slice = chronicleText.slice(match.index, match.index + ERRATUM_SCAN_CHARS);
    if (/VOID|legal hold/i.test(slice)) {
      continue;
    }
    if (!best || num > best.num) {
      best = { num, suffix: match[2], index: match.index };
    }
  }"""
new = """const ERRATUM_HEADING = /^## ERRATUM-(\\d+)([A-Z])/gm;
const ERRATUM_SCAN_CHARS = 1200;

export function resolvePolicyToken(chronicleText) {
  let best = null;
  for (const match of chronicleText.matchAll(ERRATUM_HEADING)) {
    const num = Number.parseInt(match[1], 10);
    const slice = chronicleText.slice(match.index, match.index + ERRATUM_SCAN_CHARS);
    if (/VOID|legal hold|NOT IN EFFECT/i.test(slice)) {
      continue;
    }
    if (!best || num > best.num) {
      best = { num, suffix: match[2], index: match.index };
    }
  }"""
if old in text:
    text = text.replace(old, new)
elif "ERRATUM_SCAN_CHARS = 1200" not in text or "NOT IN EFFECT" not in text:
    raise SystemExit("chronicle.js repair missing")
chronicle.write_text(text)

toll = Path("/app/src/model/toll.js")
toll_text = toll.read_text()
old_lookup = """export function lookupTurn(scheduleTurn, delayTurns, policy) {
  const executionTurn = scheduleTurn + delayTurns;
  if (policy === "POLICY_V2") {
    if (delayTurns > 0) {
      return scheduleTurn;
    }
    return executionTurn;
  }
  if (delayTurns > 0) {
    return scheduleTurn;
  }
  return executionTurn;
}"""
new_lookup = """export function lookupTurn(scheduleTurn, delayTurns, policy) {
  const executionTurn = scheduleTurn + delayTurns;
  if (policy === "POLICY_V2") {
    return executionTurn;
  }
  if (delayTurns > 0) {
    return scheduleTurn;
  }
  return executionTurn;
}"""
if old_lookup in toll_text:
    toll_text = toll_text.replace(old_lookup, new_lookup)
elif "if (policy === \"POLICY_V2\") {\n    return executionTurn;" not in toll_text:
    raise SystemExit("toll.js lookupTurn repair missing")
toll.write_text(toll_text)

summary = Path("/app/src/adjudicate/summary.js")
summary_text = summary.read_text()
if '"ERRATUM-7F": "INC-2024-0614-DRIFT"' in summary_text:
    summary_text = summary_text.replace(
        '"ERRATUM-7F": "INC-2024-0614-DRIFT"',
        '"ERRATUM-7F": "INC-2024-0615-PRISM"',
    )
if '"DRAFT-SHARD-A": "INC-2024-0615-PRISM"' in summary_text:
    summary_text = summary_text.replace(
        '"DRAFT-SHARD-A": "INC-2024-0615-PRISM"',
        '"DRAFT-SHARD-A": "INC-2024-0614-DRIFT"',
    )
if '"ERRATUM-7F": "INC-2024-0615-PRISM"' not in summary_text:
    raise SystemExit("summary.js erratum mapping repair missing")
if '"DRAFT-SHARD-A": "INC-2024-0614-DRIFT"' not in summary_text:
    raise SystemExit("summary.js draft mapping repair missing")
summary.write_text(summary_text)
PYEOF

node /app/src/cli/triage-entry.js

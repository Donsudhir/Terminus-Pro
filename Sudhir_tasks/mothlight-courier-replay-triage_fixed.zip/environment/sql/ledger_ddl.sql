CREATE TABLE IF NOT EXISTS replay_ledger (
  replay_id VARCHAR PRIMARY KEY,
  player VARCHAR NOT NULL,
  schedule_turn INTEGER NOT NULL,
  route_id VARCHAR NOT NULL,
  ledger_toll INTEGER NOT NULL,
  moves_json VARCHAR NOT NULL
);

SELECT
  replay_id,
  player,
  schedule_turn,
  route_id,
  ledger_toll,
  moves_json
FROM replay_ledger
ORDER BY replay_id;

INSERT INTO replay_ledger
SELECT
  replay_id,
  player,
  schedule_turn,
  route_id,
  ledger_toll,
  moves_json
FROM read_csv_auto(?);

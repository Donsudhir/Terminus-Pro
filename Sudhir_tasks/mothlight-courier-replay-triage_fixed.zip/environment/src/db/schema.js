export const LEDGER_COLUMNS = [
  "replay_id",
  "player",
  "schedule_turn",
  "route_id",
  "ledger_toll",
  "moves_json",
];

export function validateLedgerRow(row) {
  for (const column of LEDGER_COLUMNS) {
    if (!(column in row)) {
      throw new Error(`ledger row missing column ${column}`);
    }
  }
}

import duckdb from "duckdb";
import { replayRowFromRecord } from "../model/replay.js";

function queryAll(connection, sql) {
  return new Promise((resolve, reject) => {
    connection.all(sql, (err, rows) => {
      if (err) {
        reject(err);
        return;
      }
      resolve(rows);
    });
  });
}

function escapeSqlString(value) {
  return value.replace(/'/g, "''");
}

export async function loadReplayLedger(csvPath) {
  const db = new duckdb.Database(":memory:");
  const connection = db.connect();
  try {
    const escaped = escapeSqlString(csvPath);
    const rows = await queryAll(
      connection,
      `SELECT
         replay_id,
         player,
         schedule_turn,
         route_id,
         ledger_toll,
         moves_json
       FROM read_csv_auto('${escaped}')
       ORDER BY replay_id`,
    );
    return rows.map(replayRowFromRecord);
  } finally {
    connection.close();
    db.close();
  }
}

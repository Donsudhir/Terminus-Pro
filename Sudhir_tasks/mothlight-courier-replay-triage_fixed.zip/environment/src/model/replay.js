export function parseMoves(movesJson) {
  const parsed = JSON.parse(movesJson);
  if (!Array.isArray(parsed)) {
    throw new Error("moves_json must be a JSON array");
  }
  return parsed.map((move, idx) => {
    if (typeof move.prism_level !== "number" || typeof move.delay_turns !== "number") {
      throw new Error(`move ${idx} missing prism_level or delay_turns`);
    }
    return {
      prism_level: move.prism_level,
      delay_turns: move.delay_turns,
    };
  });
}

export function replayRowFromRecord(record) {
  return {
    replay_id: String(record.replay_id),
    player: String(record.player),
    schedule_turn: Number(record.schedule_turn),
    route_id: String(record.route_id),
    ledger_toll: Number(record.ledger_toll),
    moves: parseMoves(String(record.moves_json)),
  };
}

export function clampPrismLevel(level) {
  if (level < 0) {
    return 0;
  }
  if (level > 3) {
    return 3;
  }
  return level;
}

export function turnBump(turn, divisor) {
  return Math.floor(turn / divisor);
}

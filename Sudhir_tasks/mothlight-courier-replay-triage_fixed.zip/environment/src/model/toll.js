import { clampPrismLevel, turnBump } from "../model/turn.js";

export function routeSurcharge(routeId, tables) {
  if (!Object.prototype.hasOwnProperty.call(tables.route_surcharges, routeId)) {
    return null;
  }
  return tables.route_surcharges[routeId];
}

export function lookupTurn(scheduleTurn, delayTurns, policy) {
  const executionTurn = scheduleTurn + delayTurns;
  if (policy === "POLICY_V2") {
    if (delayTurns > 0) {
      return scheduleTurn;
    }
    return executionTurn;
  }
  if (delayTurns > 0) {
    return scheduleTurn;
  }
  return executionTurn;
}

export function computeMoveToll(move, scheduleTurn, routeId, policy, tables) {
  const surcharge = routeSurcharge(routeId, tables);
  if (surcharge === null) {
    return null;
  }
  const delay = move.delay_turns || 0;
  const turn = lookupTurn(scheduleTurn, delay, policy);
  const prismIdx = clampPrismLevel(move.prism_level);
  const base = tables.prism_base_tolls[prismIdx];
  const bump = turnBump(turn, tables.turn_bump_divisor);
  return base + surcharge + bump;
}

export function computeReplayToll(replay, policy, tables) {
  let total = 0;
  for (const move of replay.moves) {
    const toll = computeMoveToll(
      move,
      replay.schedule_turn,
      replay.route_id,
      policy,
      tables,
    );
    if (toll === null) {
      return null;
    }
    total += toll;
  }
  return total;
}

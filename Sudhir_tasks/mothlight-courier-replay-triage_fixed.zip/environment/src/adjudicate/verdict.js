import { computeReplayToll } from "../rules/prism.js";
import { isValidRoute } from "../rules/loader.js";

export function buildVerdict(replay, policyToken, tables) {
  const routeOk = isValidRoute(replay.route_id, tables);
  const computed = routeOk
    ? computeReplayToll(replay, policyToken, tables)
    : null;
  const accepted =
    routeOk && computed !== null && computed === replay.ledger_toll;
  return {
    replay_id: replay.replay_id,
    accepted,
    computed_toll: computed === null ? -1 : computed,
    ledger_toll: replay.ledger_toll,
    route_id: replay.route_id,
  };
}

import { loadReplayLedger } from "../db/ledger.js";
import { loadActivePolicy } from "../rules/chronicle.js";
import { loadTollTables } from "../rules/loader.js";
import { buildVerdict } from "./verdict.js";
import { buildIncidentSummary } from "./summary.js";
import { stableSortVerdicts } from "../util/json.js";

export async function triageReplays({ ledgerPath, chronicleDir }) {
  const [replays, policy, tables] = await Promise.all([
    loadReplayLedger(ledgerPath),
    loadActivePolicy(chronicleDir),
    loadTollTables(),
  ]);

  const verdicts = stableSortVerdicts(
    replays.map((replay) => buildVerdict(replay, policy.token, tables)),
  );

  return {
    schema_version: 2,
    hotfix_epoch: tables.hotfix_epoch,
    rule_basis: policy.basis,
    incidents: buildIncidentSummary(policy.basis, replays, verdicts),
    verdicts,
  };
}

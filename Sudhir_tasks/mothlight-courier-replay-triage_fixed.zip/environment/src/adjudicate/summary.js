const INCIDENT_BY_BASIS = {
  "ERRATUM-7F": "INC-2024-0614-DRIFT",
  "DRAFT-SHARD-A": "INC-2024-0615-PRISM",
};

export function buildIncidentSummary(policyBasis, replays, verdicts) {
  const rejected = verdicts.filter((verdict) => !verdict.accepted);
  const incidentId =
    INCIDENT_BY_BASIS[policyBasis] ?? "INC-2024-0615-PRISM";
  return [
    {
      incident_id: incidentId,
      summary:
        `Replay triage used ${policyBasis}; ${rejected.length} submissions ` +
        "disagree with ledger tolls after the prism hotfix.",
      affected_replays: rejected.length,
    },
  ];
}

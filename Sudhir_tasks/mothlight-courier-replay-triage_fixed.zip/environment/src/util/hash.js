import crypto from "node:crypto";

export function digestReport(report) {
  const payload = JSON.stringify({
    schema_version: report.schema_version,
    rule_basis: report.rule_basis,
    verdicts: report.verdicts,
  });
  return crypto.createHash("sha256").update(payload).digest("hex");
}

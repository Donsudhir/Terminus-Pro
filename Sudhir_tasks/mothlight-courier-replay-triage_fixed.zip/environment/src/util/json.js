import fs from "node:fs/promises";
import path from "node:path";

export async function readJsonFile(filePath) {
  const raw = await fs.readFile(filePath, "utf8");
  return JSON.parse(raw);
}

export async function writeJsonFile(filePath, value) {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  await fs.writeFile(filePath, `${JSON.stringify(value, null, 2)}\n`, "utf8");
}

export function stableSortVerdicts(verdicts) {
  return [...verdicts].sort((a, b) => a.replay_id.localeCompare(b.replay_id));
}

import fs from "node:fs/promises";
import path from "node:path";

export async function listChronicleFiles(chronicleDir) {
  const entries = await fs.readdir(chronicleDir, { withFileTypes: true });
  return entries
    .filter((entry) => entry.isFile())
    .map((entry) => path.join(chronicleDir, entry.name))
    .sort();
}

export async function readChronicleBundle(chronicleDir) {
  const files = await listChronicleFiles(chronicleDir);
  const parts = [];
  for (const filePath of files) {
    const body = await fs.readFile(filePath, "utf8");
    parts.push(`===== ${path.basename(filePath)} =====\n${body}`);
  }
  return parts.join("\n\n");
}

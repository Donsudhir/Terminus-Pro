export { computeMoveToll, computeReplayToll } from "../model/toll.js";

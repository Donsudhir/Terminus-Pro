export function executionTurn(scheduleTurn, delayTurns) {
  return scheduleTurn + delayTurns;
}

export function isDelayed(move) {
  return (move.delay_turns || 0) > 0;
}

/** Used by legacy prism adapters — schedule-turn lookup for delayed POLICY_V2 moves. */
export function prismLookupTurn(scheduleTurn, delayTurns, policy) {
  if (policy === "POLICY_V2" && isDelayed({ delay_turns: delayTurns })) {
    return scheduleTurn;
  }
  return executionTurn(scheduleTurn, delayTurns);
}

import path from "node:path";
import { fileURLToPath } from "node:url";
import { readJsonFile } from "../util/json.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export async function loadTollTables() {
  const tablesPath = path.join(__dirname, "../../config/toll_tables.json");
  return readJsonFile(tablesPath);
}

export function isValidRoute(routeId, tables) {
  return tables.valid_routes.includes(routeId);
}

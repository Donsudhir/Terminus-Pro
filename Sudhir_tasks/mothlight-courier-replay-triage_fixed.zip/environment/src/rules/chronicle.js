import { readChronicleBundle } from "../util/paths.js";

const ERRATUM_HEADING = /^## ERRATUM-(\d+)([A-Z])/gm;
const ERRATUM_SCAN_CHARS = 500;

export function resolvePolicyToken(chronicleText) {
  let best = null;
  for (const match of chronicleText.matchAll(ERRATUM_HEADING)) {
    const num = Number.parseInt(match[1], 10);
    const slice = chronicleText.slice(match.index, match.index + ERRATUM_SCAN_CHARS);
    if (/VOID|legal hold/i.test(slice)) {
      continue;
    }
    if (!best || num > best.num) {
      best = { num, suffix: match[2], index: match.index };
    }
  }
  if (best) {
    const slice = chronicleText.slice(best.index, best.index + ERRATUM_SCAN_CHARS);
    const tokenMatch = slice.match(/Policy token:\s*(POLICY_V\d+)/i);
    if (tokenMatch) {
      return {
        token: tokenMatch[1].toUpperCase(),
        basis: `ERRATUM-${best.num}${best.suffix}`,
      };
    }
  }

  const draftMatch = chronicleText.match(/Effective policy:\s*(POLICY_V\d+)/i);
  if (draftMatch) {
    return {
      token: draftMatch[1].toUpperCase(),
      basis: "DRAFT-SHARD-A",
    };
  }
  return {
    token: "POLICY_V1",
    basis: "DEFAULT-FALLBACK",
  };
}

export async function loadActivePolicy(chronicleDir) {
  const bundle = await readChronicleBundle(chronicleDir);
  return resolvePolicyToken(bundle);
}

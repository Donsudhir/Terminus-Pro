#!/usr/bin/env node
import path from "node:path";
import { triageReplays } from "../index.js";
import { writeJsonFile } from "../util/json.js";
import { parseArgs } from "./args.js";

async function main() {
  const options = parseArgs(process.argv);
  const report = await triageReplays({
    ledgerPath: path.resolve(options.ledger),
    chronicleDir: path.resolve(options.chronicle),
  });
  await writeJsonFile(path.resolve(options.out), report);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});

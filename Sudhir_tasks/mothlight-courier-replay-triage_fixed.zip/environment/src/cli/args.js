export function parseArgs(argv) {
  const options = {
    ledger: "/app/data/replays.csv",
    chronicle: "/app/data/chronicle",
    out: "/app/output/triage_report.json",
  };
  for (let i = 2; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--ledger" && argv[i + 1]) {
      options.ledger = argv[++i];
    } else if (arg === "--chronicle" && argv[i + 1]) {
      options.chronicle = argv[++i];
    } else if (arg === "--out" && argv[i + 1]) {
      options.out = argv[++i];
    }
  }
  return options;
}

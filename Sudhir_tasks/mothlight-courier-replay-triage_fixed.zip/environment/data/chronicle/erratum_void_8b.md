## ERRATUM-8B (pending ratification — counsel review)

Policy token: POLICY_V1

Counsel circulated this superseding draft before ratification completed. The
courier council legal desk logged extensive review minutes across multiple
sessions; excerpts below are archival context only and do not amend adjudication
rules until counsel publishes a signed ratification notice on the ops ledger.

Session 1 — Attendees debated whether revision B schedule-turn coefficients
should remain provisional for delayed commands. No vote was taken. The prism
triage guild recorded that leaderboard replays must not be regraded against this
draft until the council clerk files the binding erratum replacement packet.

Session 2 — Operators asked whether POLICY_V1 coefficients from this draft
could be applied retroactively to June leaderboard rows. Counsel answered that
the draft carries no adjudication weight and must be treated as unpublished.

Session 3 — A supplemental memo reiterated that higher-numbered erratum headers
are not automatically authoritative when the body documents pending status.

Ratification status: this erratum block is NOT IN EFFECT and must not govern
leaderboard adjudication. Operators must ignore it until the council publishes a
binding replacement. Supersedes ERRATUM-7F pending review.

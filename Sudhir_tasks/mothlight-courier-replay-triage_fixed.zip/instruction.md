The Mothlight Courier replay triage service under `/app` is rejecting valid
leaderboard submissions after the June prism-toll hotfix. Repair the Node
library so regenerating `/app/output/triage_report.json` via
`node /app/src/cli/triage-entry.js` produces a deterministic report that the
verifier can grade.

The library loads replay rows through DuckDB, reads contradictory incident
material under `/app/data/chronicle/`, and consults `/app/config/toll_tables.json`
plus `/app/contracts/report-schema.json`. Regenerated reports must satisfy that
contract for schema_version, hotfix_epoch, incidents, verdicts, and rule_basis.
When chronicle shards, operator drafts, and errata disagree, only the binding
ratified erratum may govern toll computation and those metadata fields. A replay
is accepted when its computed toll matches the ledger toll and its route is
valid in the coefficient tables. Writing the JSON by hand is not enough; tests
regenerate the report through the triage entrypoint, so source fixes under
`/app` are required.

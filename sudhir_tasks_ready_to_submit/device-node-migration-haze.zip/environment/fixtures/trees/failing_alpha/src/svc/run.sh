#!/bin/sh
echo alpha

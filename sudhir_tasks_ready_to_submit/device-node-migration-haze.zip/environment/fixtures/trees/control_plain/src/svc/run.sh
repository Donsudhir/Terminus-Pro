#!/bin/sh
echo plain

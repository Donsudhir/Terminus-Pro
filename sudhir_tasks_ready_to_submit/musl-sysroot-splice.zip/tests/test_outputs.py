"""Verifier for musl-sysroot-splice assembly outputs."""

from __future__ import annotations

import json
import os
import subprocess
import tempfile
import time
from pathlib import Path

import pytest

PAYLOAD = Path("/app/output/payload")
REPORT = Path("/app/output/probe_report.json")
STAGE = Path("/app/output/stage")
BUILD = Path("/app/tools/build_payload.sh")
ALPHA = Path("/app/vendor/alpha")
BRAVO = Path("/app/vendor/bravo")
CHARLIE = Path("/app/vendor/charlie")
MUSL_LIBC = Path("/usr/lib/x86_64-linux-musl/libc.a")


def _rebuild_helpers() -> None:
    subprocess.run(["make", "-C", "/app/mod_common"], check=True)


def _rebuild() -> None:
    _rebuild_helpers()
    subprocess.run(["bash", BUILD.as_posix()], check=True, cwd="/app")


@pytest.fixture(scope="module", autouse=True)
def _built_once() -> None:
    """Rebuild helpers and the public assembly entrypoint once per module."""
    _rebuild()


def _read_report() -> dict:
    return json.loads(REPORT.read_text(encoding="utf-8"))


def _file_digest(path: Path) -> str:
    proc = subprocess.run(
        ["sha256sum", path.as_posix()],
        capture_output=True,
        text=True,
        check=True,
    )
    return proc.stdout.split()[0]


def _qemu_stdout() -> str:
    qemu = "qemu-x86_64"
    missing = subprocess.run(
        ["bash", "-lc", f"command -v {qemu}"],
        capture_output=True,
    ).returncode
    if missing != 0:
        proc = subprocess.run(
            [PAYLOAD.as_posix()],
            capture_output=True,
            text=True,
            check=False,
        )
    else:
        proc = subprocess.run(
            [qemu, PAYLOAD.as_posix()],
            capture_output=True,
            text=True,
            check=False,
        )
    return proc.stdout


def test_no_packaged_musl_compiler_shortcut() -> None:
    """Packaged musl compiler wrappers must not be on PATH."""
    for wrap in ("musl-gcc", "x86_64-linux-musl-gcc"):
        proc = subprocess.run(["bash", "-lc", f"command -v {wrap}"], capture_output=True)
        assert proc.returncode != 0, f"{wrap} still on PATH"


def test_entrypoint_runs_stubbed_helpers_not_comments() -> None:
    """Entrypoint must execute knit/pack binaries; comments or dead name refs fail."""
    knit = Path("/app/bin/knit_main")
    pack = Path("/app/bin/pack_main")
    knit_backup = knit.read_bytes()
    pack_backup = pack.read_bytes()
    knit_mode = knit.stat().st_mode
    pack_mode = pack.stat().st_mode
    try:
        # Replace helpers with failing stubs. Keep mtimes ahead of sources so
        # build_payload.sh's `make -C mod_common` does not rebuild them.
        stub = b"#!/bin/sh\nexit 42\n"
        future = time.time() + 86_400
        for path, mode in ((knit, knit_mode), (pack, pack_mode)):
            path.write_bytes(stub)
            path.chmod(0o755)
            os.utime(path, (future, future))
        proc = subprocess.run(
            ["bash", BUILD.as_posix()],
            cwd="/app",
            capture_output=True,
            text=True,
        )
        assert proc.returncode != 0, (
            "build_payload.sh must invoke live knit/pack helpers; "
            "string mentions alone must not pass"
        )
    finally:
        knit.write_bytes(knit_backup)
        pack.write_bytes(pack_backup)
        knit.chmod(knit_mode)
        pack.chmod(pack_mode)
        _rebuild()


def test_public_stage_matches_live_knit_pack_seal() -> None:
    """Stage left by the entrypoint must match a fresh knit/pack/seal helper run."""
    assert STAGE.is_dir(), "entrypoint must leave /app/output/stage"

    with tempfile.TemporaryDirectory(prefix="knit-live-") as tmp:
        knit_stage = Path(tmp)
        subprocess.run(
            [
                "/app/bin/knit_main",
                ALPHA.as_posix(),
                BRAVO.as_posix(),
                knit_stage.as_posix(),
            ],
            check=True,
        )
        assert (STAGE / "include" / "courier_abi.h").read_text(
            encoding="utf-8"
        ) == (knit_stage / "include" / "courier_abi.h").read_text(encoding="utf-8")
        assert _file_digest(STAGE / "lib" / "crt1.o") == _file_digest(
            knit_stage / "lib" / "crt1.o"
        )
        assert _file_digest(STAGE / "lib" / "crti.o") == _file_digest(
            knit_stage / "lib" / "crti.o"
        )
        assert _file_digest(STAGE / "lib" / "crtn.o") == _file_digest(
            knit_stage / "lib" / "crtn.o"
        )

    with tempfile.TemporaryDirectory(prefix="pack-live-") as tmp:
        rsp = Path(tmp) / "pack.rsp"
        subprocess.run(
            [
                "/app/bin/pack_main",
                BRAVO.as_posix(),
                CHARLIE.as_posix(),
                rsp.as_posix(),
            ],
            check=True,
        )
        assert (STAGE / "pack.rsp").read_text(encoding="utf-8") == rsp.read_text(
            encoding="utf-8"
        )
        assert Path(str(STAGE / "pack.rsp") + ".tag.c").read_text(
            encoding="utf-8"
        ) == Path(str(rsp) + ".tag.c").read_text(encoding="utf-8")

    with tempfile.TemporaryDirectory(prefix="seal-live-") as tmp:
        flags = Path(tmp) / "seal.flags"
        subprocess.run(
            [
                "/app/bin/seal_main",
                STAGE.as_posix(),
                "unused",
                flags.as_posix(),
            ],
            check=True,
        )
        assert (STAGE / "seal.flags").read_text(encoding="utf-8") == flags.read_text(
            encoding="utf-8"
        )


def test_payload_uses_staged_musl_inputs() -> None:
    """Final ELF must be fully static and linked from staged musl vendor inputs."""
    assert MUSL_LIBC.is_file()
    assert (BRAVO / "lib" / "libc.a").is_file()
    assert _file_digest(BRAVO / "lib" / "libc.a") == _file_digest(MUSL_LIBC)

    # Knit staged musl CRT (bravo) + overlay headers, not alpha's interp CRT.
    assert "CXR-7F" in (STAGE / "include" / "courier_abi.h").read_text(encoding="utf-8")
    assert _file_digest(STAGE / "lib" / "crt1.o") == _file_digest(BRAVO / "lib" / "crt1.o")
    assert _file_digest(STAGE / "lib" / "crt1.o") != _file_digest(ALPHA / "lib" / "crt1.o")

    # Pack searched the musl vendor root and sealed a static link line.
    rsp_lines = [
        ln.strip()
        for ln in (STAGE / "pack.rsp").read_text(encoding="utf-8").splitlines()
        if ln.strip()
    ]
    assert rsp_lines[0] == f"-L{BRAVO}/lib"
    assert "-lslots" in rsp_lines
    assert "-lc" in rsp_lines
    seal = (STAGE / "seal.flags").read_text(encoding="utf-8")
    assert "-static" in seal
    assert f"{STAGE}/lib/crt1.o" in seal
    assert f"{STAGE}/lib/crti.o" in seal

    # No INTERP alone is insufficient — require musl identity in the artifact.
    prog = subprocess.run(
        ["readelf", "-l", PAYLOAD.as_posix()],
        capture_output=True,
        text=True,
        check=True,
    )
    assert "INTERP" not in prog.stdout

    strings = subprocess.run(
        ["strings", "-a", PAYLOAD.as_posix()],
        capture_output=True,
        text=True,
        check=True,
    ).stdout.lower()
    assert "musl" in strings, "payload must embed musl identity from staged libc"


def test_knit_stages_overlay_headers_and_bravo_crt() -> None:
    """Knit helper must stage alpha overlay headers with bravo CRT objects."""
    with tempfile.TemporaryDirectory(prefix="knit-stage-") as tmp:
        stage = Path(tmp)
        subprocess.run(
            ["/app/bin/knit_main", ALPHA.as_posix(), BRAVO.as_posix(), stage.as_posix()],
            check=True,
        )
        abi = (stage / "include" / "courier_abi.h").read_text(encoding="utf-8")
        assert "CXR-7F" in abi
        assert _file_digest(stage / "lib" / "crt1.o") == _file_digest(BRAVO / "lib" / "crt1.o")
        assert _file_digest(stage / "lib" / "crt1.o") != _file_digest(ALPHA / "lib" / "crt1.o")


def test_pack_prefers_bravo_slots_and_tag() -> None:
    """Pack helper must prefer bravo libslots and embed the BRAVO lane tag."""
    with tempfile.TemporaryDirectory(prefix="pack-stage-") as tmp:
        rsp = Path(tmp) / "pack.rsp"
        subprocess.run(
            [
                "/app/bin/pack_main",
                BRAVO.as_posix(),
                CHARLIE.as_posix(),
                rsp.as_posix(),
            ],
            check=True,
        )
        lines = [ln.strip() for ln in rsp.read_text(encoding="utf-8").splitlines() if ln.strip()]
        assert any(ln == f"-L{BRAVO}/lib" for ln in lines)
        assert lines[0] == f"-L{BRAVO}/lib"
        assert "-lslots" in lines
        tag_src = Path(str(rsp) + ".tag.c").read_text(encoding="utf-8")
        assert "BRAVO" in tag_src
        assert "CHARLIE" not in tag_src


def test_seal_json_derives_live_ledger() -> None:
    """Seal json mode must hash the payload and parse live probe stdout."""
    with tempfile.TemporaryDirectory(prefix="seal-stage-") as tmp:
        root = Path(tmp)
        payload = root / "payload"
        report_path = root / "probe_report.json"
        # Ephemeral stdout capture path (mkstemp) — no fixed basename literal.
        fd, stdout_name = tempfile.mkstemp(prefix="probe-", suffix=".out")
        os.close(fd)
        stdout_path = Path(stdout_name)
        try:
            payload.write_bytes(bytes(range(64)))
            stdout_path.write_text(
                "MARKER=CXR-7F\nTHREAD=7\nERRNO=2\nLANE_TAG=BRAVO\n",
                encoding="utf-8",
            )
            subprocess.run(
                [
                    "/app/bin/seal_main",
                    payload.as_posix(),
                    stdout_path.as_posix(),
                    report_path.as_posix(),
                ],
                check=True,
            )
            report = json.loads(report_path.read_text(encoding="utf-8"))
            assert report["schema_version"] == "1"
            assert report["payload_digest"] == _file_digest(payload)
            assert report["settlement"] is True
            assert [row["name"] for row in report["rows"]] == ["marker", "thread", "errno"]
            assert all(row["ok"] is True for row in report["rows"])
            assert all("detail" in row for row in report["rows"])
        finally:
            stdout_path.unlink(missing_ok=True)


def test_artifact_present() -> None:
    """Payload ELF exists at /app/output/payload and is executable."""
    assert PAYLOAD.is_file(), "payload missing"
    assert PAYLOAD.stat().st_size > 64
    assert os.access(PAYLOAD, os.X_OK)


def test_elf_has_no_interp() -> None:
    """Fully static payload must not carry a PT_INTERP program interpreter."""
    proc = subprocess.run(
        ["readelf", "-l", PAYLOAD.as_posix()],
        capture_output=True,
        text=True,
        check=True,
    )
    assert "INTERP" not in proc.stdout


def test_runtime_marker_match() -> None:
    """qemu-user stdout includes MARKER=CXR-7F from the release contract."""
    out = _qemu_stdout()
    assert "MARKER=CXR-7F" in out


def test_runtime_thread_slot() -> None:
    """qemu-user stdout reports THREAD=7 for the thread-local probe."""
    out = _qemu_stdout()
    assert "THREAD=7" in out


def test_runtime_errno_slot() -> None:
    """qemu-user stdout reports ERRNO=2 after the intentional failed open."""
    out = _qemu_stdout()
    assert "ERRNO=2" in out


def test_runtime_lane_tag() -> None:
    """qemu-user stdout reports LANE_TAG=BRAVO from the release contract."""
    out = _qemu_stdout()
    assert "LANE_TAG=BRAVO" in out


def test_summary_all_true() -> None:
    """Ledger settlement is true and every row ok flag is true."""
    report = _read_report()
    assert report["schema_version"] == "1"
    assert report["settlement"] is True
    assert all(row["ok"] is True for row in report["rows"])
    assert all("detail" in row for row in report["rows"])


def test_summary_count() -> None:
    """Ledger contains exactly three rows named marker, thread, errno."""
    report = _read_report()
    assert len(report["rows"]) == 3
    names = [row["name"] for row in report["rows"]]
    assert names == ["marker", "thread", "errno"]


def test_digest_matches_artifact() -> None:
    """payload_digest matches the on-disk artifact bytes."""
    report = _read_report()
    assert report["payload_digest"] == _file_digest(PAYLOAD)

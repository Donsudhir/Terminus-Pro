#ifndef STEP_PACK_H
#define STEP_PACK_H

int step_pack(const char *a, const char *b, const char *out_path);

#endif

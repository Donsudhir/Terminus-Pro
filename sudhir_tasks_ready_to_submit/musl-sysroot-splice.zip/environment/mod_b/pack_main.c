#include "step_pack.h"
#include <stdio.h>

int main(int argc, char **argv) {
    if (argc != 4) {
        fprintf(stderr, "usage: pack_main <bravo> <charlie> <out_path>\n");
        return 2;
    }
    return step_pack(argv[1], argv[2], argv[3]) == 0 ? 0 : 1;
}

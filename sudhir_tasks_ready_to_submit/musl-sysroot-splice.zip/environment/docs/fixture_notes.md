# Fixture notes

Probe case stubs under `/app/probe/cases/` are operator placeholders.
Authoritative probe tokens and ledger shape live in the release contract.

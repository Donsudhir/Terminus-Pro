Courier build under /app should ship a fully static musl binary at
/app/output/payload and a behavior ledger at /app/output/probe_report.json.
Stock assembly still links, but qemu-user disagrees with the release contract
at /app/docs/release_contract.md: we still see a program interpreter, the
identity / thread-local / errno probes and lane-tag stdout are off, and
settlement stays false.

Get /app/tools/build_payload.sh producing a payload that clears those probes
and a deterministic probe_report.json matching that release contract
(schema_version, payload_digest, rows, settlement; each row has name, ok,
and detail). The ledger contains exactly three rows — marker, thread, and
errno. LANE_TAG must appear in runtime stdout as named in the contract, but
it is not a ledger row. Runtime stdout must also include the MARKER, THREAD,
and ERRNO lines named in the contract. Tests rebuild through the entrypoint
and also exercise the assembly helpers the entrypoint calls, so hand-written
bytes or a wrapper that skips those helpers will not pass.

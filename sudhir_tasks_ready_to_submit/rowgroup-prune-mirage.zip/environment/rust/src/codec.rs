use crate::model::{Cell, Page};
use std::fs::File;
use std::io::{BufRead, BufReader, BufWriter, Write};
use std::path::Path;

pub(crate) fn read_csv(path: &Path) -> Result<Vec<Cell>, Box<dyn std::error::Error>> {
    let file = File::open(path)?;
    let mut rows = Vec::new();
    for (line_no, line) in BufReader::new(file).lines().enumerate() {
        let line = line?;
        if line_no == 0 && line.starts_with("origin,") {
            continue;
        }
        if line.trim().is_empty() {
            continue;
        }
        let fields: Vec<&str> = line.split(',').collect();
        if fields.len() != 4 {
            return Err(format!("{}:{}: expected four columns", path.display(), line_no + 1).into());
        }
        rows.push(Cell {
            origin: fields[0].parse()?,
            present: fields[1].parse()?,
            amount: fields[2].parse()?,
            region: fields[3].trim().to_owned(),
        });
    }
    Ok(rows)
}

pub(crate) fn write_pages(path: &Path, pages: &[Page]) -> Result<(), Box<dyn std::error::Error>> {
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let file = File::create(path)?;
    let mut out = BufWriter::new(file);
    writeln!(out, "H|3")?;
    for page in pages {
        writeln!(
            out,
            "P|{}|{}|{}|{}|{}|{}|{}|{}",
            page.id,
            page.generation,
            page.mark.low,
            page.mark.high,
            u8::from(page.mark.has_absent),
            page.region_low,
            page.region_high,
            page.cells.len()
        )?;
        for cell in &page.cells {
            writeln!(
                out,
                "R|{}|{}|{}|{}",
                cell.present, cell.origin, cell.amount, cell.region
            )?;
        }
    }
    out.flush()?;
    Ok(())
}

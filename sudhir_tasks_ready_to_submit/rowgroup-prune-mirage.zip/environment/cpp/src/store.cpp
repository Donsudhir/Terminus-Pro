#include "loam/store.hpp"

#include "loam/exec.hpp"
#include "loam/plan.hpp"

#include <fstream>
#include <stdexcept>
#include <string>

namespace loam {
namespace {

std::vector<std::string> split(const std::string& line) {
    std::vector<std::string> fields;
    std::size_t start = 0;
    while (true) {
        const auto end = line.find('|', start);
        fields.push_back(line.substr(start, end - start));
        if (end == std::string::npos) {
            break;
        }
        start = end + 1;
    }
    return fields;
}

}  // namespace

std::vector<Slab> load_store(const std::filesystem::path& path) {
    std::ifstream input(path);
    if (!input) {
        throw std::runtime_error("cannot open store: " + path.string());
    }

    std::vector<Slab> slabs;
    std::string line;
    while (std::getline(input, line)) {
        if (line.empty() || line.rfind("H|", 0) == 0) {
            continue;
        }
        const auto page = split(line);
        if (page.size() != 9 || page[0] != "P") {
            throw std::runtime_error("bad page record in " + path.string());
        }
        Slab slab;
        slab.id = std::stoull(page[1]);
        slab.generation = static_cast<std::uint8_t>(std::stoul(page[2]));
        slab.low = std::stoll(page[3]);
        slab.high = std::stoll(page[4]);
        slab.has_absent = page[5] == "1";
        slab.region_low = page[6];
        slab.region_high = page[7];
        const auto row_count = std::stoull(page[8]);
        for (std::size_t i = 0; i < row_count; ++i) {
            if (!std::getline(input, line)) {
                throw std::runtime_error("short page in " + path.string());
            }
            const auto row = split(line);
            if (row.size() != 5 || row[0] != "R") {
                throw std::runtime_error("bad row record in " + path.string());
            }
            const auto presence = static_cast<std::uint8_t>(std::stoul(row[1]));
            const auto origin = static_cast<std::uint8_t>(std::stoul(row[2]));
            const auto amount = std::stoll(row[3]);
            slab.cells.push_back({presence, static_cast<Origin>(origin), amount, row[4]});
            slab.presence_lane.push_back(presence);
            slab.origin_lane.push_back(origin);
            slab.amount_lane.push_back(amount);
            slab.region_lane.push_back(row[4]);
        }
        slabs.push_back(std::move(slab));
    }
    return slabs;
}

CaseResult run_case(const CaseSpec& spec) {
    const auto slabs = load_store(spec.store_path);
    Tally total;
    for (const auto& slab : slabs) {
        const Gate gate = turn_b(slab, spec.probe);
        const auto label = turn_d(gate, spec.probe);
        (void)label;
        const Tally part = spec.probe.lane == Lane::Batch
            ? sweep_c(slab, spec.probe, gate)
            : walk_row(slab, spec.probe, gate);
        total = sweep_e(total, part);
    }
    return {
        spec.case_id,
        total,
        static_cast<std::int64_t>(slabs.size()),
        spec.probe.lane,
        spec.probe.skipping,
    };
}

}  // namespace loam
